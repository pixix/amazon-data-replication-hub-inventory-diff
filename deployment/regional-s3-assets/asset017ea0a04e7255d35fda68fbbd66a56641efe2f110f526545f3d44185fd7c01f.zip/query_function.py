import time
import boto3
import os

# athena constant
DATABASE = 'srcdb'
TABLE1 = 'srctable'
TABLE2 = 'desttable'

# S3 constant
# S3_OUTPUT = 's3://website-31415/result/'
S3_OUTPUT = os.environ['S3_OUTPUT_LOCATION']+'orc/'+time.strftime('%Y%m%d_%H%M%S')


def lambda_handler(event, context):

    # created query

    # query = "SELECT a.* FROM %s.%s a LIMIT 120000000;" % (DATABASE, TABLE1)
    # query = "SELECT a.* FROM %s.%s a LEFT JOIN %s.%s b on a.key = b.key where b.key is NULL;" % (DATABASE, TABLE1, DATABASE, TABLE2)

    # export in orc format
    query = """
            CREATE TABLE my_orc_ctas_table WITH (
                external_location = '%s',
                format = 'ORC')
            AS SELECT a.* FROM %s.%s a LEFT JOIN %s.%s b 
            on a.key = b.key where b.key is NULL;
            DROP TABLE my_orc_ctas_table;""" % (S3_OUTPUT,DATABASE, TABLE1, DATABASE, TABLE2)

    # athena client
    client = boto3.client('athena')

    # Execution
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': DATABASE
        },
        ResultConfiguration={
            'OutputLocation': S3_OUTPUT,
        }
    )
"""
    # get query execution id
    query_execution_id = response['QueryExecutionId']
    print(query_execution_id)

    # get execution status
    for i in range(1, 1 + RETRY_COUNT):

        # get query execution
        query_status = client.get_query_execution(QueryExecutionId=query_execution_id)
        query_execution_status = query_status['QueryExecution']['Status']['State']

        if query_execution_status == 'SUCCEEDED':
            print("STATUS:" + query_execution_status)
            break

        if query_execution_status == 'FAILED':
            raise Exception("STATUS:" + query_execution_status)

        else:
            print("STATUS:" + query_execution_status)
            time.sleep(i)
    else:
        client.stop_query_execution(QueryExecutionId=query_execution_id)
        raise Exception('TIME OVER')

    # get query results
    result = client.get_query_results(QueryExecutionId=query_execution_id)
    print(result)

    # get data
    if len(result['ResultSet']['Rows']) == 2:

        email = result['ResultSet']['Rows'][1]['Data'][1]['VarCharValue']

        return email

    else:
        return None
"""